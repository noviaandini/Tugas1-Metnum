﻿Public Class count

    Function tambah(ByVal a As Double, ByVal b As Double) As String
        Return a + b
    End Function

    Function kurang(ByVal a As Double, ByVal b As Double) As String
        Return a - b
    End Function

    Function bagi(ByVal a As Double, ByVal b As Double) As String
        Return a / b
    End Function

    Function pangkat(ByVal a As Double, ByVal b As Double) As String
        Return a ^ b
    End Function

    Function deret(ByVal a As Double, ByVal b As Double) As String
        Return 2 * (a * a) + (4 * b) - 1
    End Function
End Class
