﻿Module Module1

    Sub Main()
        Dim a, b As Double
        Dim Pilihan As Integer
        Dim kal As New count

        Console.WriteLine(" Operasi Hitung ")


        Console.WriteLine(" 1. Penambahan ")
        Console.WriteLine(" 2. Pengurangan ")
        Console.WriteLine(" 3. Pembagian ")
        Console.WriteLine(" 4. Pangkat ")
        Console.WriteLine(" 5. Deret Fungsi 2x^-4x+1 ")
        Console.Write(" Pilihan : ")



        Pilihan = Console.ReadLine
        Console.Clear()
        Console.Write(" Masukkan angka 1 : ")
        a = Console.ReadLine()

        Console.Write(" Masukan angka 2  : ")
        b = Console.ReadLine()

        Console.WriteLine()


        Select Case UCase(Pilihan)
            Case "1"
                Console.Write(" Hasil Penambahan  : " & kal.tambah(a, b))
                Console.ReadLine()
            Case "2"
                Console.Write(" Hasil Pengurangan : " & kal.kurang(a, b))
                Console.ReadLine()
            Case "3"
                Console.Write(" Hasil Pembagian   : " & kal.bagi(a, b))
                Console.ReadLine()
            Case "4"
                Console.WriteLine(" Hasil Pangkat : " & kal.pangkat(a, b))
                Console.ReadLine()
            Case "5"
                Console.WriteLine(" Hasil Deret Fungsi 2x^-4x+1 : " & kal.deret(a, a))
                Console.WriteLine(" Hasil Deret Fungsi 2x^-4x+1 : " & kal.deret(b, b))
                Console.ReadLine()
            Case Else
                Console.Write(" Masukkan Salah ")
                Console.ReadLine()
        End Select

    End Sub

End Module
